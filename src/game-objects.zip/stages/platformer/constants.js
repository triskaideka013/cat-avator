const KeyboardKeys = {
  ArrowRight: "ArrowRight",
  ArrowLeft: "ArrowLeft",
  ArrowUp: "ArrowUp",
  ArrowDown: "ArrowDown",
  KeyL: "KeyL",
  KeyR: "KeyR",
  KeyV: "KeyV",
  KeyY: "KeyY", 
  KeyN: "KeyN"
};
